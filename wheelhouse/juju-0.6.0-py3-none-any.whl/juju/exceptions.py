class DeadEntityException(Exception):
    pass
